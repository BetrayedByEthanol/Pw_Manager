const VAULTY_NATIVE_HOST = "com.vaulty.native_host";
const USE_MOCK_VAULTY = false;

function getRuntimeApi() {
  return globalThis.browser?.runtime ?? globalThis.chrome?.runtime;
}

async function sendVaultyNativeMessage(message, { timeoutMs = 5000 } = {}) {
  const runtime = getRuntimeApi();

  if (!runtime?.sendNativeMessage) {
    throw new Error("Native messaging API is not available.");
  }

  const response = await Promise.race([
    new Promise((resolve, reject) => {
      runtime.sendNativeMessage(VAULTY_NATIVE_HOST, message, (reply) => {
        const err = runtime.lastError;
        if (err) {
          reject(new Error(err.message));
          return;
        }
        resolve(reply);
      });
    }),
    new Promise((_, reject) => {
      setTimeout(() => reject(new Error("Vaulty native host timed out.")), timeoutMs);
    }),
  ]);

  if (!response || typeof response !== "object") {
    throw new Error("Invalid Vaulty native host response.");
  }

  if (response.requestId !== message.requestId) {
    throw new Error("Vaulty native host response requestId mismatch.");
  }

  if (response.ok === false) {
    throw new Error(response.error?.message ?? "Vaulty native host request failed.");
  }

  return response;
}

async function vaultyGeneratePassword(policy = {}) {
  if (USE_MOCK_VAULTY) {
    return vaultyGeneratePassword(policy)
  }

  return sendVaultyNativeMessage({
    type: "GENERATE_PASSWORD",
    requestId: crypto.randomUUID(),
    origin: location.origin,
    policy,
  });
}

async function vaultySaveCredential(request) {
  if (USE_MOCK_VAULTY) {
    return vaultySaveCredential(relayRequest);
  }

  return sendVaultyNativeMessage({
    ...request,
    type: "SAVE_CREDENTIAL",
    requestId: crypto.randomUUID(),
  });
}